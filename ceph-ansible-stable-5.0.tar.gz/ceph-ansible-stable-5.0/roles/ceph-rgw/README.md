# Ansible role: ceph-rgw

Documentation is available at http://docs.ceph.com/ceph-ansible/.
