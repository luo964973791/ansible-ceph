ceph-ansible
============
Ansible playbooks for Ceph, the distributed filesystem.

Please refer to our hosted documentation here: https://docs.ceph.com/projects/ceph-ansible/en/latest/

You can view documentation for our ``stable-*`` branches by substituting ``master`` in the link
above for the name of the branch. For example: https://docs.ceph.com/projects/ceph-ansible/en/stable-5.0/
